
import requests
from flask import Flask, render_template, Markup, current_app
import sqlite3


conn = sqlite3.connect("jobs.db")
c = conn.cursor()
c.execute("drop table jobs")
c.execute('''CREATE TABLE jobs
             (id text, title text, details BLOB)''')
# c.execute("DELETE * FROM jobs")
repos_url = 'https://api.github.com/users/awesome-jobs/repos'

repo = requests.get(repos_url)
open_issues = repo.json()[1]['open_issues']

issues_url = 'https://api.github.com/repos/awesome-jobs/vietnam/issues'
issues = requests.get(issues_url)
per_page = len(issues.json())
paged = open_issues // per_page + 1

for page in range(1, paged+1):
    parameters = issues_url + '?page={0}'.format(page)
    jobpages = requests.get(parameters)
    for job in jobpages.json():
        job_id = str(job['id'])
        title = str(job['title'])
        details = str(job['body'])
        c.executemany("INSERT INTO jobs VALUES (?,?,?)", [(job_id, title, details)])
        conn.commit()
conn.close()

app = Flask(__name__)


@app.route('/')
def show_all_jobs():
    conn = sqlite3.connect("jobs.db")
    sql = 'select id, title from jobs '
    data1 = conn.execute(sql)
    data = data1.fetchall()
    return render_template('show-all-jobs.html', jobs=data)


@app.route('/jobs/<string:id>')
def jobs_details(id=None):
    conn = sqlite3.connect("jobs.db")
    query = 'select title, details from jobs where id == {0}'.format(id)
    job = conn.execute(query)
    row = job.fetchall()
    return render_template('job-detail.html', job=row[0][1].split("###"))


if __name__ == '__main__':
    app.run(debug=True)
